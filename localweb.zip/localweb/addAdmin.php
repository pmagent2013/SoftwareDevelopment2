<!DOCTYPE html>
<html>
<header>
	<link rel="stylesheet" type="text/css" href="style.css">
</header>



<body>
<a href='index.php'>Home </a>| 
<a href='lost.php'> Submit Lost Item </a>|
<a href='searchLost.php'> Search for Lost Item </a>|
<a href='found.php'> Submit Found Item </a>|
<a href='searchFound.php'> Search for Found Item </a>|
<a href='Modify.php'> Modify Submitted Item Status </a>|
<a href='quickLinks.php'> Quick Links </a>|
<a href='login.php'> Admin </a>


<h1>Want to add a new admin team</h1>


<script>var days = null;</script>
<?php

# Connect to MySQL server and the database
require( 'includes/connect_db.php' ) ;

# Includes these helper functions
require( 'includes/helpers.php' ) ;




if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    addAdmin($dbc, $username, $password, $email);

}

?>
<form action="addAdmin.php" method="POST">
<table>
<tr>
<td>Username:</td><td><input type="text" name="username" value="<?php if
(isset($_POST['username'])) echo $_POST['username']; ?>"></td>
</tr>
<tr>
<td>Password:</td><td><input type="text" name="password" value="<?php if
(isset($_POST['password'])) echo $_POST['password']; ?>"></td>
</tr>
<td>Email:</td><td><input type="text" name="email" value="<?php if
(isset($_POST['email'])) echo $_POST['email']; ?>"></td>
</tr>
</table>
<p><input type="Submit" value="Add Admin"></p>
</form>
<?php



# Close the connection
mysqli_close( $dbc ) ;
?>



</body>



</html>