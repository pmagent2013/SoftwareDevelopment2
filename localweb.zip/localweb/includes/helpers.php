<?php
$debug = false;
error_reporting(E_ALL & ~E_NOTICE);
# Shows the records in lost
function show_recordsLost($dbc) {
$query = 'SELECT dateLost, itemType, color, brand, buildingLost, roomLost, description FROM lost ORDER BY datereported' ;

# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Lost</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Lost</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Lost</TH>';
  echo '<TH>Room Lost</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateLost'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingLost'] . '</TD>' ;
    echo '<TD>' . $row['roomLost'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}



# Shows the records in lost
function show_recordsLostRecent($dbc, $days) {
$query = 'SELECT dateLost, itemType, color, brand, buildingLost, roomLost, description 
          FROM lost 
          WHERE dateLost BETWEEN DATE_SUB(NOW(), INTERVAL '. $days . ' DAY) AND NOW();';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Lost</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Lost</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Lost</TH>';
  echo '<TH>Room Lost</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateLost'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingLost'] . '</TD>' ;
    echo '<TD>' . $row['roomLost'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}


# Shows the records in lost
function show_recordsFoundRecent($dbc, $days) {
$query = 'SELECT dateFound, itemType, color, brand, buildingFound, roomFound, description 
          FROM found 
          WHERE dateFound BETWEEN DATE_SUB(NOW(), INTERVAL '. $days . ' DAY) AND NOW();';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Found</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Found</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Found</TH>';
  echo '<TH>Room Found</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateFound'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingFound'] . '</TD>' ;
    echo '<TD>' . $row['roomFound'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

# Shows the records in lost
function show_recordsLostRecentAdmin($dbc, $days) {
$query = 'SELECT id, dateLost, itemType, color, brand, buildingLost, roomLost, description, currentStatus 
          FROM lost 
          WHERE dateLost BETWEEN DATE_SUB(NOW(), INTERVAL '. $days . ' DAY) AND NOW();';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Lost</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>ID</TH>';
  echo '<TH>Date Lost</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Lost</TH>';
  echo '<TH>Room Lost</TH>';
  echo '<TH>Description</TH>';
  echo '<TH>Status</TH>';  
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['id'] . '</TD>' ;
    echo '<TD>' . $row['dateLost'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingLost'] . '</TD>' ;
    echo '<TD>' . $row['roomLost'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '<TD>' . $row['currentStatus'] . '</TD>' ;    
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

function show_recordsFoundRecentAdmin($dbc, $days) {
$query = 'SELECT id, dateFound, itemType, color, brand, buildingFound, roomFound, description, currentStatus 
          FROM found 
          WHERE dateFound BETWEEN DATE_SUB(NOW(), INTERVAL '. $days . ' DAY) AND NOW();';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Found</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>ID</TH>';
  echo '<TH>Date Found</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Found</TH>';
  echo '<TH>Room Found</TH>';
  echo '<TH>Description</TH>';
  echo '<TH>Status</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['id'] . '</TD>' ;
    echo '<TD>' . $row['dateFound'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingFound'] . '</TD>' ;
    echo '<TD>' . $row['roomFound'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '<TD>' . $row['currentStatus'] . '</TD>' ;    
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

function show_users($dbc) {
$query = 'SELECT id, username, password, email FROM user ORDER BY id' ;

# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Lost</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>ID</TH>';
  echo '<TH>Username</TH>';
  echo '<TH>Password</TH>';
  echo '<TH>Email</TH>';  
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['id'] . '</TD>' ;
    echo '<TD>' . $row['username'] . '</TD>' ;
    echo '<TD>' . $row['password'] . '</TD>' ;    
    echo '<TD>' . $row['email'] . '</TD>' ;    
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}



#this is the function that shows link records
function show_link_records($dbc) {
	# Create a query to get the num, last name of the dead presidents
$query = 'SELECT num, lname FROM presidents ORDER BY num DESC' ;

# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Dead Presidents</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Number</TH>';    
  echo '<TH>Last Name</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    
  $alink = '<A HREF=linkypresidents.php?num=' . $row['num']. '>' . $row['num'] . '</A>' ;
    echo '<TR>' ;
    echo '<TD ALIGN=right>' . $alink . '</TD>' ;
    echo '<TD>' . $row['lname'] . '</TD>' ;
    echo '</TR>' ;    
    
  }
  
  # End the table
  
  echo '</TABLE>';
  
  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

function show_record($dbc, $num) {
	
$query = 'SELECT num, lname, fname FROM presidents WHERE num = ' . $num ;

# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Dead Presidents</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Number</TH>';
  echo '<TH>First Name</TH>';
  echo '<TH>Last Name</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['num'] . '</TD>' ;
    echo '<TD>' . $row['fname'] . '</TD>' ;
    echo '<TD>' . $row['lname'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

# Inserts a record into the lost table
function insert_lostItem($dbc, $dateLost, $itemType, $color, $brand, $buildingLost, $roomLost, $description) {
  $query = 'INSERT INTO lost(dateLost, itemType, color, brand, buildingLost, roomLost, description) VALUES ( "' . $dateLost . '", "'. $itemType .'", "'. $color .'", "'. $brand .'", "'. $buildingLost .'", "'. $roomLost .'", "'. $description .'" )' ;
  show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  header("Location: index.php?msg=Record+Sucessfully+Inserted");
  
}

# Inserts a record into the found table
function insert_foundItem($dbc, $dateFound, $itemType, $color, $brand, $buildingFound, $roomFound, $description) {
  $query = 'INSERT INTO found(dateFound, itemType, color, brand, buildingFound, roomFound, description) VALUES ( "' . $dateFound . '", "'. $itemType .'", "'. $color .'", "'. $brand .'", "'. $buildingFound .'", "'. $roomFound .'", "'. $description .'" )' ;
  show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  header("Location: index.php?msg=Record+Sucessfully+Inserted");
}

function update_lostItem($dbc, $id, $currentStatus) {
  $query = 'UPDATE lost set currentStatus = "'.$currentStatus.'" where id = '.$id.'' ;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;  
  return $results ;  
}

function update_foundItem($dbc, $id, $currentStatus) {
  $query = 'UPDATE found set currentStatus = "'.$currentStatus.'" where id = '.$id.'' ;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;  
  return $results ;  
}

function delete_foundItem($dbc, $id) {
  $query = 'DELETE from found where id = '.$id.'' ;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;  
  return $results ;  
}

function delete_lostItem($dbc, $id) {
  $query = 'DELETE from lost where id = '.$id.'' ;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;  
  return $results ;  
}

function addAdmin($dbc, $username, $password, $email) {
  $query = 'INSERT INTO user(username, password, email) VALUES ( "' . $username . '", "'. $password .'", "'. $email .'")' ;
  show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}

function update_Admin($dbc, $id, $username, $password) {
  $query = 'UPDATE user set username = "'.$username.'", password = "'.$password.'" where id = '.$id.'' ;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;  
  return $results ;  
}

function delete_Admin($dbc, $id) {
  $query = 'DELETE from user where id = '.$id.'' ;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;  
  return $results ;  
}

# Shows the query as a debugging aid
function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

# Checks the query results as a debugging aid
function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}



function valid_number($num) {
if(empty($num) || !is_numeric($num))
return false ;
else {
$num = intval($num) ;
if($num <= 0)
return false ;
}
return true ;
}

function valid_name($name) {
if(empty($name)){
return false;}
return true;
}

function valid_date($date) {
if(empty($date)){
return false;}
return true;
}












function show_recordsFoundType($dbc, $itemType) {
$query = 'SELECT dateFound, itemType, color, brand, buildingFound, roomFound, description 
          FROM found 
          WHERE itemType= '. $itemType . ';';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Found</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Found</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Found</TH>';
  echo '<TH>Room Found</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateFound'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingFound'] . '</TD>' ;
    echo '<TD>' . $row['roomFound'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

function show_recordsLostType($dbc, $type) {
$query = 'SELECT dateLost, itemType, color, brand, buildingLost, roomLost, description 
          FROM lost 
          WHERE itemType= '. $type . ';';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Lost</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Lost</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Lost</TH>';
  echo '<TH>Room Lost</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateLost'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingLost'] . '</TD>' ;
    echo '<TD>' . $row['roomLost'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}




function show_recordsLostSearch($dbc, $type, $color,$brand) {
$query = 'SELECT dateLost, itemType, color, brand, buildingLost, roomLost, description 
          FROM lost 
          WHERE itemType = '. $type . '
          AND color = ' . $color . ' 
          AND brand = ' . $brand . ' ;';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Lost</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Lost</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Lost</TH>';
  echo '<TH>Room Lost</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateLost'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingLost'] . '</TD>' ;
    echo '<TD>' . $row['roomLost'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}


function show_recordsFoundSearch($dbc, $type, $color,$brand) {
$query = 'SELECT dateFound, itemType, color, brand, buildingFound, roomFound, description 
          FROM found 
          WHERE itemType = '. $type . '
          AND color = ' . $color . ' 
          AND brand = ' . $brand . ' ;';
           
# Execute the query
$results = mysqli_query( $dbc , $query ) ;

# Show results
if( $results )
{
  # But...wait until we know the query succeeded before
  # starting the table.
  echo '<H1>Items Found</H1>' ;
  echo '<TABLE border="1">';
  echo '<TR>';
  echo '<TH>Date Found</TH>';
  echo '<TH>Item Type</TH>';
  echo '<TH>Color</TH>';
  echo '<TH>Brand</TH>';
  echo '<TH>Building Found</TH>';
  echo '<TH>Room Found</TH>';
  echo '<TH>Description</TH>';
  echo '</TR>';

  # For each row result, generate a table row
  while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  {
    echo '<TR>' ;
    echo '<TD>' . $row['dateFound'] . '</TD>' ;
    echo '<TD>' . $row['itemType'] . '</TD>' ;    
    echo '<TD>' . $row['color'] . '</TD>' ;
    echo '<TD>' . $row['brand'] . '</TD>' ;
    echo '<TD>' . $row['buildingFound'] . '</TD>' ;
    echo '<TD>' . $row['roomFound'] . '</TD>' ;
    echo '<TD>' . $row['description'] . '</TD>' ;
    echo '</TR>' ;
  }

  # End the table
  echo '</TABLE>';

  # Free up the results in memory
  mysqli_free_result( $results ) ;
}
else
{
  # If we get here, something has gone wrong
  echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
}
}

function init() {
    # The dabase we connect to
    $DB_NAME = 'site_db';

    # Connect to the database, create it if necessary
    $dbc = connect_db($DB_NAME);

    # Populate the database
    populate_db($dbc);

    return $dbc;
}

# Populates the database
function populate_db($dbc) {
    # Create lost  table, if it doesnt exist
    $query  = '
	create table if not exists lost
	(
		dateReported timestamp default current_timestamp,
		dateLost date,  
		id int auto_increment not null,
		itemType text not null,
		color text not null,
		brand text,
		buildingLost text,
		roomLost text,
		description text,
		primary key(id)
	); ';
    show_query($query);

    $results = mysqli_query($dbc,$query);
    check_results( $results );
	


    # Check if table is already populated
    $query = 'SELECT COUNT(*) FROM lost';
    show_query( $query );

    $results = mysqli_query($dbc,$query);
    check_results( $results );

    if($results) {
        $row = mysqli_fetch_array($results, MYSQLI_NUM);

        if($row[0] > 0)
            return;
    }

    # If we get here, populate the table
    $query = "
	INSERT INTO lost(dateLost, itemtype, color, brand, buildingLost, roomLost, description)
		values('2014-12-7', 'watch', 'silver', 'rolex', 'Hancock', '2023', 'CAT WATCH'),
					('2014-12-8', 'coat', 'red', 'll bean', 'Foy', 'c3', 'fly'),
					('1964-12-4', 'dad', 'mostly white with a little black on his dads side', 'german', 'dinning hall', null, 'i miss him'),
					('2014-12-4', 'laptop', 'black', 'Gateway', 'Donnelly', '101', 'cooter'), 
                    ('2014-12-6', 'doge', 'gold', 'retriever', 'Upper New', 'i2', 'picture on cryptocurrency'); ";
    show_query($query);

    $results = mysqli_query($dbc,$query);
    check_results( $results );
	
    # Create found table, if it doesnt exist
    $query  = '
	create table if not exists found
	(
		dateReported timestamp default current_timestamp,
		dateFound date, 
		id int auto_increment not null,
		itemType text not null,
		color text not null,
		brand text,
		buildingFound text,
		roomFound text,
		description text,
		primary key(id)
	); ';
    show_query($query);

    $results = mysqli_query($dbc,$query);
    check_results( $results );
	


    # Check if table is already populated
    $query = 'SELECT COUNT(*) FROM found';
    show_query( $query );

    $results = mysqli_query($dbc,$query);
    check_results( $results );

    if($results) {
        $row = mysqli_fetch_array($results, MYSQLI_NUM);

        if($row[0] > 0)
            return;
    }

    # If we get here, populate the table
    $query = "
	INSERT INTO found(dateFound, itemtype, color, brand, buildingFound, roomFound, description)
		values('2014-12-8', 'watch', 'silver', 'rolex', 'Hancock', '2023', 'CAT WATCH'),
					('2014-12-7', 'phone', 'black', 'Motorola', 'Student Center', '3023', 'cracked'),
                    ('2014-12-6', 'ufo', 'silver', 'Asgard', 'Dinning Hall', '', 'damaged sublight engines'),
					('2014-12-5', 'laptop', 'black', 'Gateway', 'Donnelly', '101', 'cooter');";
    show_query($query);

    $results = mysqli_query($dbc,$query);
    check_results( $results );
	
	
    # Create user table, if it doesnt exist
    $query  = '
	create table if not exists user
	(
		dateRegistered timestamp default current_timestamp,
		id int auto_increment not null,
		username text,
		password text,
		email text,
		primary key(id)
	);';
    show_query($query);

    $results = mysqli_query($dbc,$query);
    check_results( $results );
	


    # Check if table is already populated
    $query = 'SELECT COUNT(*) FROM user';
    show_query( $query );

    $results = mysqli_query($dbc,$query);
    check_results( $results );

    if($results) {
        $row = mysqli_fetch_array($results, MYSQLI_NUM);

        if($row[0] > 0)
            return;
    }

    # If we get here, populate the table
    $query = '
	INSERT INTO user(username, password, email)
			values("admin2", "cooter", "torinreilly@gmail.com"),
            ("admin", "gaze11e", "pmagent2013@gmail.com");';
    show_query($query);

    $results = mysqli_query($dbc,$query);
    check_results( $results );
	

}

# Connects to the database and creates one, if necessary.
function connect_db ($dbname) {
    # Connect to the database, if we fail assume the DB doesnt exist
    $dbc = @mysqli_connect ( 'localhost', 'root', '', $dbname );

    if($dbc) {
        mysqli_set_charset( $dbc, 'utf8' ) ;
        return $dbc;
    }

    # Create the database
    $dbc = @mysqli_connect ( 'localhost', 'root', '', '' );
/*
    $query = 'DROP DATABASE IF EXISTS $dbname';
    show_query( $query );
    $results = mysqli_query($dbc, $query);
    check_results($result);
*/
    $query = 'CREATE DATABASE site_db';
    show_query( $query );

    $results = mysqli_query($dbc, $query);
    check_results($results);

    # Close connection since we dont need it
    mysqli_close( $dbc );

    # Connect to the (newly created) database
    $dbc = @mysqli_connect ( 'localhost', 'root', '', $dbname )
        OR die ( mysqli_connect_error() ) ;

    # Set encoding to match PHP script encoding.
    mysqli_set_charset( $dbc, 'utf8' ) ;

    return $dbc;
}






?>