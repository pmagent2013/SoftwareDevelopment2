<!DOCTYPE html>
<html>
<header>
	<link rel="stylesheet" type="text/css" href="style.css">
</header>



<body>
<a href='index.php'>Home </a>| 
<a href='lost.php'> Submit Lost Item </a>|
<a href='searchLost.php'> Search for Lost Item </a>|
<a href='found.php'> Submit Found Item </a>|
<a href='searchFound.php'> Search for Found Item </a>|
<a href='Modify.php'> Modify Submitted Item Status </a>|
<a href='quickLinks.php'> Quick Links </a>|
<a href='login.php'> Admin </a>


<h1>Hello Admin</h1>
<p>You can delete an admin from this page </p>

<?php

# Connect to MySQL server and the database
require( 'includes/connect_db.php' ) ;

# Includes these helper functions
require( 'includes/helpers.php' ) ;

# Show the records
show_users($dbc);



if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
    $id = $_POST['id'];    
    delete_Admin($dbc, $id);

}

?>
<form action="adminDelete.php" method="POST">
<table>
<tr>
<td>ID:</td><td><input type="text" name="id" value="<?php if
(isset($_POST['id'])) echo $_POST['id']; ?>"></td>
</tr>
</table>
<p><input type="Submit" value="Delete Item"></p>
</form>
<?php



# Close the connection
mysqli_close( $dbc ) ;
?>



</body>



</html>