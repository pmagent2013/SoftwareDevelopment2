<!DOCTYPE html>
<html>
<header>
	<link rel="stylesheet" type="text/css" href="style.css">
</header>



<body>
<a href='index.php'>Home </a>| 
<a href='lost.php'> Submit Lost Item </a>|
<a href='searchLost.php'> Search for Lost Item </a>|
<a href='found.php'> Submit Found Item </a>|
<a href='searchFound.php'> Search for Found Item </a>|
<a href='Modify.php'> Modify Submitted Item Status </a>|
<a href='quickLinks.php'> Quick Links </a>|
<a href='login.php'> Admin </a>


<h1>Hello Admin</h1>
<p>You can change the status and remove items from this page </p>
<a href='adminLost.php'>Modify Status of Lost Items</a>
<br>
<a href='adminFound.php'>Modify Status of Found Items</a>
<br>
<a href='adminLostDelete.php'>Delete Lost Items</a>
<br>
<a href='adminFoundDelete.php'>Delete Found Items</a>
<br>
<a href='addAdmin.php'>Add an Admin</a>
<br>
<a href='modifyAdmin.php'>Change Username/Password for Admin</a>
<br>
<a href='adminDelete.php'>Delete Admin</a>

</body>



</html>